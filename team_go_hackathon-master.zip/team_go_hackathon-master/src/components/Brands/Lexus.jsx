import React from "react";

const Lexus = () => {
  return <div className="section">Lexus</div>;
};

export default Lexus;
