import React from "react";

const Tayota = () => {
  return <div className="section">Toyota</div>;
};

export default Tayota;
