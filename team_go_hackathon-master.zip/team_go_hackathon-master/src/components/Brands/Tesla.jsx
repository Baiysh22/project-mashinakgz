import React from "react";

const Tesla = () => {
  return <div className="section">Tesla</div>;
};

export default Tesla;
