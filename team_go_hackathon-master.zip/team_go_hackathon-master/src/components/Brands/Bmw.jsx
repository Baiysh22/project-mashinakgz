import React from "react";

const Bmw = () => {
  return <div className="section"></div>;
};

export default Bmw;
